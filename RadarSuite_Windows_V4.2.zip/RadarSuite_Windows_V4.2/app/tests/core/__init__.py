"""Core module tests"""
