"""Widgets module tests"""
