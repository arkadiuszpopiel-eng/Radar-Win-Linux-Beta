"""Utils module tests"""
